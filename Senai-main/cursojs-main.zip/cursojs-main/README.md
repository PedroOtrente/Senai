# Curso - Programação em JavaScript ![Senai](https://img.shields.io/badge/SENAI-FFFFFF?style=for-the-badge&logo=senai&logoColor=black)

## ✨ Descrição
Repositório utilizado para armazenar e exposicionar os conteúdos e projetos desenvolvidos durante o curso de Programação em JavaScript do SENAI
## 🛠 Ferramentas
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black) ![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
	![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white) 	![Git](https://img.shields.io/badge/GIT-E44C30?style=for-the-badge&logo=git&logoColor=white) 	[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/daniel-bento11)
## 🟡 Status
## 📋 Aulas
### Aula 1 - 14/09
- Pensamento Computacional: Os Pilares da Computação - Abstração, Decomposição, Reconhecimento de Padrões, Algoritmos e Automação - Conceitos e Exemplificação. 
- Git e GitHub: Conceitos, vantagens, diferenças e prática
- Visão Sistêmica e Versionamento: 
## 🧑 Autores
## 📚 Referências
