const idade = 20

if (idade >=18){
    console.log("Você é um adulto");
} 
else {
    console.log("Você ainda não é um adulto!")
}