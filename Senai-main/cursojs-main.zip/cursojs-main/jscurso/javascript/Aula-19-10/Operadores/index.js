const idade = 15;
const sexo  = "Masculino";

if (idade >= 18 && sexo == "Masculino") {
    console.log("Bem-vindo ao Exército.");
} else {
    console.log("Obrigado.");
}
