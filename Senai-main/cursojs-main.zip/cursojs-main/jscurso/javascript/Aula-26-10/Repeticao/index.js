/**
 *  Estruturas de Repetição
 * 
 * while
 * do while
 * for
 * 
 * 
 * FOR - Para
 * for(iniciador; condição; incremento)
 */


for (let i = 0; i<10; i++){
    console.log(i)
}