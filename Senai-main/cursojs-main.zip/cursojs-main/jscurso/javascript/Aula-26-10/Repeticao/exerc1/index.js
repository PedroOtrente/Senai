// Tabuáda

const tabuada = 5;

for (i=0;i<=10;i++){
    console.log(`${tabuada} x ${i} = ${tabuada*i}`)
}