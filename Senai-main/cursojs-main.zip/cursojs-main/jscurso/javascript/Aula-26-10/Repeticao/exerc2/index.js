let soma = 0

for (let i=1;i<=10;i++){
    soma=soma+i;
}

console.log(`Soma: ${soma}`);